document.getElementById('topup-form').addEventListener('submit', function(e) {
  e.preventDefault();
  const userId = document.getElementById('userId').value;
  const nominal = document.getElementById('nominal').value;

  fetch('../backend/topup.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: `userId=${userId}&nominal=${nominal}`
  })
  .then(res => res.json())
  .then(data => {
    document.getElementById('result').textContent = data.message;
  });
});
