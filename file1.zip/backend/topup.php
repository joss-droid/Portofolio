<?php
$host = 'localhost';
$db = 'topup_db';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
  die("Koneksi gagal: " . $conn->connect_error);
}

$userId = $_POST['userId'];
$nominal = $_POST['nominal'];

$stmt = $conn->prepare("INSERT INTO topup_requests (user_id, nominal) VALUES (?, ?)");
$stmt->bind_param("si", $userId, $nominal);
$stmt->execute();

echo json_encode(["status" => "sukses", "message" => "Permintaan top-up diterima."]);
$conn->close();
?>
