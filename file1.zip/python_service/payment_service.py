from flask import Flask, request, jsonify
app = Flask(__name__)

@app.route('/validate_payment', methods=['POST'])
def validate_payment():
    data = request.json
    user_id = data.get('user_id')
    amount = data.get('amount')

    if amount > 0:
        return jsonify({"status": "valid", "user_id": user_id})
    return jsonify({"status": "invalid"})

if __name__ == '__main__':
    app.run(port=5001)
