CREATE DATABASE topup_db;
USE topup_db;

CREATE TABLE topup_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id VARCHAR(100),
  nominal INT,
  status VARCHAR(20) DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
