const express = require('express');
const bodyParser = require('body-parser');
const fetch = require('node-fetch');
const app = express();
app.use(bodyParser.json());

app.post('/topup', async (req, res) => {
  const { userId, nominal } = req.body;

  const validate = await fetch('http://localhost:5001/validate_payment', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user_id: userId, amount: nominal })
  });

  const result = await validate.json();
  if (result.status === 'valid') {
    res.json({ status: 'OK', message: 'Top-up berhasil divalidasi' });
  } else {
    res.json({ status: 'ERROR', message: 'Validasi gagal' });
  }
});

app.listen(3000, () => console.log('API berjalan di port 3000'));
